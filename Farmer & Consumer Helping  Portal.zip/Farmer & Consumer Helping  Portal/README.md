# 🌾 AgriPortal - Farmer & Consumer Portal

![AgriPortal](https://img.shields.io/badge/AgriPortal-Farmer%20%26%20Consumer%20Portal-green)
![HTML](https://img.shields.io/badge/HTML5-orange)
![CSS](https://img.shields.io/badge/CSS3-blue)
![JavaScript](https://img.shields.io/badge/JavaScript-yellow)
![Year](https://img.shields.io/badge/Year-2026-brightgreen)

## 📸 Project Preview

> Add your project screenshot here:

![AgriPortal Dashboard](images/dashboard.png)

---

## 📖 About the Project

**AgriPortal** is a Farmer & Consumer Portal designed to provide a simple digital platform for managing agricultural information.

The portal includes farmer/consumer login and registration, dashboard information, market prices, crop management, quality and quantity calculation, order history, profile management, weather information, and multilingual support.

The project interface supports:

- 🇬🇧 English
- 🇧🇩 বাংলা
- 🇮🇳 हिन्दी

---

## 🎯 Project Objectives

- Provide an easy-to-use agricultural portal.
- Help farmers manage crop information.
- Display today's mandi/market prices.
- Calculate crop value based on quality and quantity.
- Maintain order history.
- Provide basic weather information.
- Support different user types.
- Provide multilingual interface support.

---

## ✨ Main Features

### 🔐 1. Login

Users can log in using:

- Mobile Number
- Password

Additional options:

- Forgot Password
- Create Account

### 📝 2. Registration

Users can create an account using:

- Full Name
- Mobile Number
- Password
- Confirm Password
- Location
- User Type

Available user types:

- 👨‍🌾 Farmer
- 🛒 Consumer
- 👨‍💼 Admin

---

## 📊 3. Dashboard

The dashboard provides an overview of important information such as:

| Section | Information |
|---|---|
| Total Income | User income overview |
| Active Crops | Currently active crops |
| Total Orders | Number of orders |
| Rice Rate | Today's rice rate per quintal |
| Market Trend | Last 7 days market trend |
| Weather | Regional weather information |

### 🌦️ Weather Information

The sample dashboard includes:

- Temperature
- Weather condition
- Humidity
- Wind speed
- Multi-day forecast

---

## 💰 4. Market Prices

The portal provides a **Today's Mandi Prices** section.

Information includes:

| Field | Description |
|---|---|
| Crop | Crop name |
| Type | Crop type |
| Price | Current price |
| Change | Price change |
| Trend | Market trend |
| Edit | Edit option |

---

## 🌱 5. My Crops

Farmers can manage crop information.

### Add New Crop

The crop form contains:

- Crop Name
- Quantity
- Unit
- Price per Unit

Supported quantity units include:

- Kilogram (kg)
- Quintal

---

## 🧮 6. Quality & Quantity Calculator

The portal contains a calculator for estimating crop value based on quality and quantity.

### Input Fields

- Crop Name
- Quantity
- Unit
- Base Rate
- Moisture %
- Impurity %

### Calculator Rules

The project uses the following rules:

**Moisture:**
- If moisture is above 12%, deduct **3 points for each percentage above 12%**.

**Impurity:**
- If impurity is above 2%, deduct **5 points for each percentage above 2%**.

### Available Actions

- Calculate
- Reset
- Download Slip

---

## 📦 7. Order History

The portal provides an order history section.

| Field | Description |
|---|---|
| Order No | Order identification |
| Crop | Crop name |
| Quantity | Ordered quantity |
| Amount | Order amount |
| Date | Order date |
| Status | Current order status |
| Edit | Edit option |

---

## 👤 8. Profile

The profile section displays:

- Name
- Mobile Number
- User Type
- Location
- Member Since

The interface also includes profile-related actions such as:

- Edit Profile
- Delete Account

---

## 🌐 9. Multilingual Support

AgriPortal includes language options for:

- English
- বাংলা
- हिन्दी

This helps make the interface accessible to users with different language preferences.

---

## 🧭 Portal Navigation

The main navigation contains:

```text
Dashboard
Market Prices
My Crops
Calculator
History
Profile
Logout
```

---

## 🛠️ Technologies Used

The uploaded project is an HTML-based web portal.

### Frontend

- HTML5
- CSS3
- JavaScript

### Interface

- Responsive web interface
- Forms
- Tables
- Dashboard cards
- Navigation sections
- Calculator interface

---

## 📁 Project Structure

A recommended project structure is:

```text
AgriPortal/
│
├── Farmer & Consumer Helping Portal.html
├── README.md
│
├── images/
│   ├── dashboard.png
│   ├── login.png
│   ├── registration.png
│   ├── market-prices.png
│   ├── my-crops.png
│   ├── calculator.png
│   ├── history.png
│   └── profile.png
│
└── assets/
    └── ...
```

> Keep the HTML filename as provided if you do not want to rename the original project file.

---

## ▶️ How to Run

### Method 1: Browser

1. Download or copy the project files.
2. Locate:
   `Farmer & Consumer Helping Portal.html`
3. Double-click the HTML file.
4. The project will open in your web browser.

### Method 2: VS Code

1. Open the project folder in **Visual Studio Code**.
2. Open the HTML file.
3. Use a browser or the **Live Server** extension.
4. View the AgriPortal interface.

---

## 🔄 Basic User Workflow

```text
Start
  ↓
Login / Register
  ↓
Select User Type
  ↓
Dashboard
  ↓
View Market Prices
  ↓
Manage Crops
  ↓
Use Quality & Quantity Calculator
  ↓
View Order History
  ↓
Manage Profile
  ↓
Logout
```

---

## ✅ Validation Rules

The project interface includes validation for fields such as:

- Mobile number should be a valid 10-digit number.
- Password should contain at least 4 characters.
- Name uses English letters according to the interface validation.
- Location uses English letters according to the interface validation.
- Crop name uses English letters according to the interface validation.

---

## 📈 Benefits

- Simple agricultural dashboard.
- Easy crop management.
- Market price visibility.
- Quality-based calculation.
- Order history management.
- Weather information.
- Multilingual interface.
- Separate user types.

---

## 🚀 Future Improvements

Possible future improvements include:

- Real-time mandi price API.
- Real-time weather API.
- Database integration.
- Secure authentication.
- Online crop marketplace.
- Farmer-to-consumer direct selling.
- Online payment integration.
- Order tracking.
- Admin management panel.
- Mobile application.
- Notification system.
- Advanced market analytics.

---

## 📸 Screenshots

Add screenshots to the `images` folder and use them in this section.

### Login

![Login](images/login.png)

### Dashboard

![Dashboard](images/dashboard.png)

### Market Prices

![Market Prices](images/market-prices.png)

### My Crops

![My Crops](images/my-crops.png)

### Calculator

![Calculator](images/calculator.png)

### Order History

![Order History](images/history.png)

### Profile

![Profile](images/profile.png)

---

## 💻 Project Purpose

The project demonstrates how a web-based agricultural portal can bring farmer and consumer-oriented features into one interface.

It combines:

```text
Farmer
   +
Consumer
   +
Market Information
   +
Crop Management
   +
Quality Calculation
   +
Order History
   +
Weather
   =
AgriPortal
```

---

## 📜 License

This project is intended for educational and project demonstration purposes.

---

## 👨‍💻 Author

**AgriPortal Project**

Farmer & Consumer Helping Portal  
© 2026 AgriPortal

---

## ⭐ Support

If you find this project useful, you can improve it by adding database connectivity, real-time agricultural APIs, secure authentication, and additional farmer/consumer services.
